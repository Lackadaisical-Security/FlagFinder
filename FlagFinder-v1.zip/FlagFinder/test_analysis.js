// Quick test of the analysis engine
const { analyzeLogs } = require('./dist/analysis/ruleEngine');

console.log('Testing FlagFinder Analysis Engine...\n');

// Test with some sample messages
const testMessages = [
  "Hey, how are you doing today?",
  "I'm really busy right now, maybe later...",
  "Leave me alone! I don't want to talk.",
  "Sure, let's hang out sometime!",
  "I hate this situation",
  "Can we chat about this?"
];

const transcript = testMessages.join('\n');
const result = analyzeLogs(transcript);

console.log('📊 Analysis Results:');
console.log('==================');
result.messages.forEach((msg, idx) => {
  console.log(`${idx + 1}. ${msg.flag} "${msg.text}"`);
  console.log(`   Reason: ${msg.reason}`);
  console.log(`   Tip: ${msg.tip}`);
  console.log(`   Sentiment: ${msg.sentiment}`);
  console.log('');
});

console.log(`📈 Question Rate: ${(result.questionRate * 100).toFixed(1)}%`);
console.log('\n✅ Analysis engine working correctly!');

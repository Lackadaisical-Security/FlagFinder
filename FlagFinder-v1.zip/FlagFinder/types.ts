export interface InputPayload {
  type: 'text' | 'audio' | 'image' | 'api';
  data: any;
  meta?: Record<string, any>;
}

export interface AnalysisResult {
  text: string;
  timestamp?: string;
  flag: '🟢' | '🟡' | '🔴';
  score: number;
  tip?: string;
}

export interface Plugin {
  name: string;
  canHandle(input: InputPayload): boolean;
  run(input: InputPayload): Promise<AnalysisResult>;
}

# FlagFinder Electron Project Scaffold

```
FlagFinder/
├── electron/
│   ├── main.ts         # Electron main process
│   └── preload.ts      # Preload script for secure IPC
├── ui/
│   ├── index.html      # HTML entry (or React root)
│   ├── App.js          # React app (if using React)
│   ├── Timeline.js     # Timeline component
│   └── DetailPane.js   # Detail pane component
├── analysis/
│   ├── ruleEngine.ts   # Rule-based and sentiment analysis
│   └── mlPlugin.ts     # (Optional) ML classifier loader
├── crypto/
│   └── crypto.ts       # AES-GCM encrypt/decrypt helpers
├── storage/
│   └── vault.ts        # Encrypted session save/load
├── package.json
├── electron-builder.yml
├── README.md
```

- All UI in `/ui/`
- Electron main/preload in `/electron/`
- Analysis engine in `/analysis/`
- Crypto helpers in `/crypto/`
- Encrypted storage in `/storage/`

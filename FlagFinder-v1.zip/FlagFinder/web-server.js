// Simple web server to serve the FlagFinder UI
const express = require('express');
const path = require('path');
const { analyzeLogs } = require('./dist/analysis/ruleEngine');
const storage = require('./dist/storage/sqlite');
const crypto = require('./dist/crypto/crypto');

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use(express.static('dist/ui'));
app.use(express.static('ui'));

// Serve the main HTML file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'ui', 'index.html'));
});

// API endpoint for analysis
app.post('/api/analyze', (req, res) => {
  try {
    const { text } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'No text provided' });
    }
    
    const result = analyzeLogs(text);
    res.json(result);
  } catch (error) {
    console.error('Analysis error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API endpoint for sessions
app.get('/api/sessions', (req, res) => {
  try {
    const sessions = storage.listSessions();
    res.json(sessions);
  } catch (error) {
    console.error('Sessions error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API endpoint to save session
app.post('/api/sessions', (req, res) => {
  try {
    const { data, encrypted } = req.body;
    const sessionId = storage.saveSession(data, encrypted ? 1 : 0);
    res.json({ sessionId });
  } catch (error) {
    console.error('Save session error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API endpoint for audit logs
app.get('/api/audit', (req, res) => {
  try {
    const logs = storage.listAuditLogs(10);
    res.json(logs);
  } catch (error) {
    console.error('Audit logs error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 FlagFinder Web UI running at http://localhost:${PORT}`);
  console.log('✅ Analysis engine ready');
  console.log('✅ Storage system ready');
  console.log('✅ Crypto system ready');
});

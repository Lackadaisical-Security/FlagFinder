import * as ort from 'onnxruntime-node';
import * as fs from 'fs';
import axios from 'axios';

let session: ort.InferenceSession | null = null;

export async function loadModel(modelPath: string) {
  session = await ort.InferenceSession.create(modelPath);
}

export async function classify(text: string, features: Record<string, number>): Promise<{ flag: string; score: number }> {
  if (!session) throw new Error('Model not loaded');
  // TODO: Preprocess text and features into model input
  // Example assumes a single string input and feature vector
  const input = {
    text: new ort.Tensor('string', [text]),
    features: new ort.Tensor('float32', Object.values(features), [1, Object.keys(features).length])
  };
  const output = await session.run(input);
  // Assume output is { flag: Tensor, score: Tensor }
  return {
    flag: String(output.flag.data[0]),
    score: Number(output.score.data[0])
  };
}

// --- Additional Features ---

// 1. Model warmup (for faster first inference)
export async function warmupModel(sampleText: string, sampleFeatures: Record<string, number>) {
  if (!session) throw new Error('Model not loaded');
  const input = {
    text: new ort.Tensor('string', [sampleText]),
    features: new ort.Tensor('float32', Object.values(sampleFeatures), [1, Object.keys(sampleFeatures).length])
  };
  await session.run(input);
}

// 2. Get model metadata (input/output names, shapes, etc.)
export function getModelInfo() {
  if (!session) throw new Error('Model not loaded');
  return {
    inputNames: session.inputNames,
    outputNames: session.outputNames,
    inputMetadata: session.inputNames.map((n: string) => (session as any).inputMetadata[n]),
    outputMetadata: session.outputNames.map((n: string) => (session as any).outputMetadata[n])
  };
}

// 3. Batched classification for multiple messages
export async function classifyBatch(texts: string[], featuresArr: Record<string, number>[]): Promise<Array<{ flag: string; score: number }>> {
  if (!session) throw new Error('Model not loaded');
  if (texts.length !== featuresArr.length) throw new Error('texts/features length mismatch');
  const featureKeys = Object.keys(featuresArr[0] || {});
  const featuresMatrix = featuresArr.map(f => featureKeys.map(k => f[k] ?? 0));
  const input = {
    text: new ort.Tensor('string', texts),
    features: new ort.Tensor('float32', featuresMatrix.flat(), [texts.length, featureKeys.length])
  };
  const output = await session.run(input);  // Assume output is { flag: Tensor, score: Tensor }
  return texts.map((_, i) => ({
    flag: String(output.flag.data[i]),
    score: Number(output.score.data[i])
  }));
}

// --- Advanced ML Features ---

// Softmax utility for logits
function softmax(logits: number[]): number[] {
  const max = Math.max(...logits);
  const exps = logits.map(x => Math.exp(x - max));
  const sum = exps.reduce((a, b) => a + b, 0);
  return exps.map(e => e / sum);
}

// Multi-label classification (for multi-flag detection)
export async function classifyMultiLabel(text: string, features: Record<string, number>): Promise<{ flags: string[]; scores: number[] }> {
  if (!session) throw new Error('Model not loaded');
  const input = {
    text: new ort.Tensor('string', [text]),
    features: new ort.Tensor('float32', Object.values(features), [1, Object.keys(features).length])
  };  const output = await session.run(input);
  // Assume output is { logits: Tensor }
  const logits = Array.from(output.logits.data as unknown as number[]);
  const scores = softmax(logits);
  // Map to flags (🟢, 🟡, 🔴) by threshold
  const flagMap = ['🟢', '🟡', '🔴'];
  const flags = scores.map((s, i) => s > 0.5 ? flagMap[i] : null).filter(Boolean) as string[];
  return { flags, scores };
}

// Embedding extraction for clustering/semantic search
export async function getEmbedding(text: string): Promise<number[]> {
  if (!session) throw new Error('Model not loaded');
  const input = { text: new ort.Tensor('string', [text]) };
  const output = await session.run(input);
  // Assume output is { embedding: Tensor }
  return Array.from(output.embedding.data as Float32Array);
}

// Export training data for Ollama (JSONL format)
import path from 'path';
export function exportOllamaTrainingData(data: Array<{ text: string; features: Record<string, number>; label: string }>, outDir = 'ollama_export') {
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir);
  const outPath = path.join(outDir, `ollama_train_${Date.now()}.jsonl`);
  const lines = data.map(d => JSON.stringify({ prompt: d.text, completion: d.label })).join('\n');
  fs.writeFileSync(outPath, lines, 'utf-8');
  return outPath;
}

// --- Further Enhancements ---

// Utility: Check if model is loaded
export function isModelLoaded() {
  return !!session;
}

// Utility: Unload model (free memory)
export function unloadModel() {
  session = null;
}

// Utility: List available ONNX models in a directory (for model selection UI)
export function listAvailableModels(dir: string): string[] {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter(f => f.endsWith('.onnx'));
}

// --- LLM Pipeline Enhancements ---

// Semantic search: cosine similarity
function cosineSimilarity(a: number[], b: number[]): number {
  const dot = a.reduce((sum, ai, i) => sum + ai * b[i], 0);
  const normA = Math.sqrt(a.reduce((sum, ai) => sum + ai * ai, 0));
  const normB = Math.sqrt(b.reduce((sum, bi) => sum + bi * bi, 0));
  return dot / (normA * normB);
}

// In-memory vector store for semantic search
let embeddingStore: Array<{ text: string; embedding: number[] }> = [];

export async function addToEmbeddingStore(text: string) {
  const embedding = await getEmbedding(text);
  embeddingStore.push({ text, embedding });
}

export function clearEmbeddingStore() {
  embeddingStore = [];
}

export async function semanticSearch(query: string, topK = 5): Promise<Array<{ text: string; score: number }>> {
  const queryEmbedding = await getEmbedding(query);
  const results = embeddingStore.map(item => ({
    text: item.text,
    score: cosineSimilarity(queryEmbedding, item.embedding)
  }));
  return results.sort((a, b) => b.score - a.score).slice(0, topK);
}

// --- RAG (Retrieval-Augmented Generation) ---
// This version supports Ollama local LLM service if available
export async function llmRAG(query: string, context: string): Promise<string> {
  // Try Ollama local service first
  try {
    const response = await axios.post('http://localhost:11434/api/generate', {
      model: 'llama3', // or your preferred model name
      prompt: `Context:\n${context}\n\nQ: ${query}\nA:`,
      stream: false
    }, { timeout: 10000 });
    if (response.data && response.data.response) {
      return response.data.response.trim();
    }
  } catch (e) {
    // Fallback to placeholder
  }
  // Fallback: simple concatenation
  return `Q: ${query}\nContext:\n${context}\nA: [LLM output here]`;
}

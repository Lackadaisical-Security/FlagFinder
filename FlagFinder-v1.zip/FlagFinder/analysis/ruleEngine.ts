// Rule-based and sentiment analysis for FlagFinder
const Sentiment = require('sentiment');
const sentiment = new Sentiment();

const KEYWORDS = {
  yellow: ["busy", "maybe", "not sure", "later", "idk", "can't"],
  red: ["leave me alone", "stop", "never", "hate you", "block"]
};

export function analyzeLogs(transcript: string | { text: string }[]): { messages: any[]; questionRate: number } {
  // Accepts plain text or array of messages
  let messages: { text: string }[] = [];
  if (typeof transcript === 'string') {
    messages = transcript.split(/\n+/).map(line => ({ text: line }));
  } else {
    messages = transcript;
  }
  let questionCount = 0;
  const results = messages.map((msg, idx) => {
    const text = msg.text;
    const s = sentiment.analyze(text);
    const isQuestion = text.trim().endsWith('?');
    if (isQuestion) questionCount++;
    let flag: '🟢' | '🟡' | '🔴' = '🟢';
    let reason = '';
    if (KEYWORDS.red.some(k => text.toLowerCase().includes(k))) {
      flag = '🔴';
      reason = 'Strong negative keyword';
    } else if (KEYWORDS.yellow.some(k => text.toLowerCase().includes(k))) {
      flag = '🟡';
      reason = 'Possible hesitation/soft no';
    } else if (s.score < -1) {
      flag = '🔴';
      reason = 'Negative sentiment';
    } else if (s.score < 0) {
      flag = '🟡';
      reason = 'Slightly negative sentiment';
    }
    return {
      ...msg,
      idx,
      flag,
      sentiment: s.score,
      isQuestion,
      reason,
      tip: getTip(flag, reason)
    };
  });
  // Compute question rate
  const questionRate = questionCount / (messages.length || 1);
  return { messages: results, questionRate };
}

function getTip(flag: string, reason: string) {
  if (flag === '🔴') return 'Consider pausing or changing topic.';
  if (flag === '🟡') return 'Maybe clarify or give space.';
  return 'All clear.';
}

export async function analyzeLogsWithML(transcript: string | { text: string }[], useML = false): Promise<any> {
  const { messages, questionRate } = analyzeLogs(transcript);
  if (!useML) return { messages, questionRate };
  
  // For each message, run ML classifier and merge
  const { classify } = require('./mlPlugin');
  const mlResults = await Promise.all(messages.map(async (msg: any) => {
    // Example: use sentiment and isQuestion as features
    const features = {
      sentiment: msg.sentiment,
      isQuestion: msg.isQuestion ? 1 : 0
    };
    try {
      const ml = await classify(msg.text, features);
      return { ...msg, mlFlag: ml.flag, mlScore: ml.score };
    } catch {
      return { ...msg, mlFlag: null, mlScore: null };
    }
  }));
  return { messages: mlResults, questionRate };
}

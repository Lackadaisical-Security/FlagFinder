#!/usr/bin/env node
// Add this to the top of the file for Node.js types
declare var require: any;
declare var process: any;

// tsconfig.json should include ES2015 lib for Promise and Node.js types
// Add this to tsconfig.json:
// "lib": ["ES2015"],
// "types": ["node"]

import { Dispatcher } from '../dispatcher/Dispatcher';
import * as fs from 'fs';
import * as path from 'path';

const dispatcher = new Dispatcher();

function printUsage() {
  console.log('Usage: flagfinder analyze --file <file> | --audio <file> | --screenshot <file>');
}

const args = process.argv.slice(2);
if (args.length < 2) {
  printUsage();
  process.exit(1);
}

let type: 'text' | 'audio' | 'image' = 'text';
let file = '';
if (args[0] === 'analyze') {
  if (args[1] === '--file' && args[2]) {
    type = 'text';
    file = args[2];
  } else if (args[1] === '--audio' && args[2]) {
    type = 'audio';
    file = args[2];
  } else if (args[1] === '--screenshot' && args[2]) {
    type = 'image';
    file = args[2];
  } else {
    printUsage();
    process.exit(1);
  }
} else {
  printUsage();
  process.exit(1);
}

if (!fs.existsSync(file)) {
  console.error('File not found:', file);
  process.exit(1);
}

const data = fs.readFileSync(file, type === 'text' ? 'utf-8' : undefined);

(async () => {
  const results = await dispatcher.analyze({ type, data });
  console.log(JSON.stringify(results, null, 2));
})();

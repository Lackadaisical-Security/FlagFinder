# FlagFinder CLI Usage

Analyze files from the command line:

```
flagfinder analyze --file chat.txt
flagfinder analyze --audio call.wav
flagfinder analyze --screenshot convo.png
```

- Supports text, audio, image inputs
- Outputs JSON or HTML report

# FlagFinder UI

- Drag-and-drop panel (HTML/Electron)
- Shows timeline of flags (🟢🟡🔴)
- Export results as JSON/HTML

See `/ui/index.html` for the web panel implementation.

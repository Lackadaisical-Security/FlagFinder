# FlagFinder UI Walkthrough

## Main Features
- **Timeline**: View chat messages with color-coded flags (🟢, 🟡, 🔴)
- **Detail Pane**: Click a message to see flag reason, tip, and suggested reply
- **LLM Training UI**: Build and export custom datasets for LLM fine-tuning
- **Semantic Search**: Search chat history using vector/embedding similarity
- **RAG (Retrieval-Augmented Generation)**: Generate answers using LLM and top search results as context
- **Cluster Visualization**: Visualize message embeddings and flag clusters in 2D
- **Session & Audit Log**: Save/load sessions, view audit log, and manage encrypted vaults

## Typical Workflow
1. **Import** chat logs (text, JSON, audio, image)
2. **Analyze** to flag messages and view timeline
3. **Explore**: Use detail pane, semantic search, and cluster visualization
4. **Train**: Build LLM datasets and export for Ollama
5. **RAG**: Generate answers using LLM and semantic context
6. **Save**: Store sessions securely and review audit logs

## Tips
- Use the "Add All Messages to Embedding Store" button before semantic search or RAG
- Use "Visualize Clusters" to see how messages group by flag
- Use the LLM Training UI to create and export new training data
- All data stays local and encrypted by default

---

For more, see `DOCUMENTATION.md` and `API_REFERENCE.md`.

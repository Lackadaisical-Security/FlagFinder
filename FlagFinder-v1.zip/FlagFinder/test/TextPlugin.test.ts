import { TextPlugin } from '../plugins/text/TextPlugin';

test('TextPlugin basic', async () => {
  const plugin = new TextPlugin();
  const result = await plugin.run({ type: 'text', data: 'hello' });
  expect(result.flag).toBe('🟢');
});

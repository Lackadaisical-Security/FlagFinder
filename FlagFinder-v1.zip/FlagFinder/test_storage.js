// Test storage and crypto functionality
const storage = require('./dist/storage/sqlite');
const crypto = require('./dist/crypto/crypto');

console.log('Testing FlagFinder Storage & Crypto...\n');

// Test audit logging
storage.logAudit('test_event', { message: 'Testing audit log functionality' });
console.log('✅ Audit logging works');

// Test encrypted vault
const testData = { messages: ['test message 1', 'test message 2'], timestamp: new Date() };
const passphrase = 'test_passphrase_123';

try {
  crypto.saveVaultLackadaisical(testData, passphrase);
  console.log('✅ Vault encryption works');
  
  const decryptedData = crypto.loadVaultLackadaisical(passphrase);
  console.log('✅ Vault decryption works');
  console.log('   Decrypted data:', JSON.stringify(decryptedData, null, 2));
} catch (e) {
  console.log('❌ Vault test failed:', e.message);
}

// Test session storage
const sessionData = { test: 'session data', messages: [1, 2, 3] };
storage.saveSession(sessionData, 0);
console.log('✅ Session storage works');

// List recent audit logs
const logs = storage.listAuditLogs(3);
console.log('\n📋 Recent Audit Logs:');
logs.forEach(log => {
  console.log(`   [${log.timestamp}] ${log.event}: ${log.details}`);
});

// List sessions
const sessions = storage.listSessions();
console.log('\n💾 Recent Sessions:');
sessions.slice(0, 3).forEach(session => {
  console.log(`   Session #${session.id} (${session.created_at}) ${session.encrypted ? '[Encrypted]' : ''}`);
});

console.log('\n✅ Storage and crypto functionality working correctly!');

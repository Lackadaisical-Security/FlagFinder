import crypto from 'crypto';
import { saveVault as saveVaultFile, loadVault as loadVaultFile } from '../storage/vault';

export function encrypt(plaintext: string, passphrase: string): string {
  const iv = crypto.randomBytes(12);
  const key = crypto.scryptSync(passphrase, 'flagfinder_salt', 32);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  let encrypted = cipher.update(plaintext, 'utf8', 'base64');
  encrypted += cipher.final('base64');
  const tag = cipher.getAuthTag();
  return [iv.toString('base64'), tag.toString('base64'), encrypted].join(':');
}

export function decrypt(ciphertext: string, passphrase: string): string {
  const [ivB64, tagB64, encrypted] = ciphertext.split(':');
  const iv = Buffer.from(ivB64, 'base64');
  const tag = Buffer.from(tagB64, 'base64');
  const key = crypto.scryptSync(passphrase, 'flagfinder_salt', 32);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  let decrypted = decipher.update(encrypted, 'base64', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

// Lackadaisical security stack: encrypt with salt, HMAC for integrity, and secure save/load
export function saveVaultLackadaisical(data: any, passphrase: string) {
  const salt = crypto.randomBytes(16).toString('base64');
  const encrypted = encrypt(JSON.stringify(data), passphrase + salt);
  const hmac = crypto.createHmac('sha256', passphrase).update(encrypted).digest('base64');
  const payload = JSON.stringify({ salt, encrypted, hmac });
  saveVaultFile(payload);
}

export function loadVaultLackadaisical(passphrase: string): any {
  const payload = JSON.parse(loadVaultFile());
  const { salt, encrypted, hmac } = payload;
  const checkHmac = crypto.createHmac('sha256', passphrase).update(encrypted).digest('base64');
  if (hmac !== checkHmac) throw new Error('Integrity check failed');
  return JSON.parse(decrypt(encrypted, passphrase + salt));
}

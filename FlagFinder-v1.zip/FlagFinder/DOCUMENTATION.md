# FlagFinder Documentation

## Overview
FlagFinder is a modular, privacy-first desktop tool for detecting social “flags” in conversations. It supports text, audio, image, and API feeds, and features a plugin-based architecture, hybrid rule/ML pipeline, semantic search, RAG, and full local encryption and audit logging.

## Setup
1. Clone the repository
2. Run `npm install` to install Node.js dependencies
3. Run `pip install -r ml/requirements.txt` for ML training/export
4. Run `npm start` to launch the Electron app
5. (Optional) Train and export your own ONNX model, place in `/models/`

## Usage
- Import chat logs (text, JSON, audio, image)
- Analyze and view flags in the timeline
- Use semantic search and RAG to generate LLM answers
- Visualize clusters and build custom LLM datasets
- All data is encrypted and auditable

## Plugin Authoring
- Implement the `Plugin` interface in `types.ts`
- Add your plugin to `dispatcher/PluginRegistry.ts`
- See `/plugins/` for examples (TextPlugin, AudioPlugin, ImagePlugin, APIPlugin)

## API Reference
- All core analysis and ML functions are exposed via Electron preload (see `electron/preload.ts`)
- REST/GraphQL endpoints available in `/api/server.ts`

## Security
- All processing and storage is local by default
- Data is encrypted at rest (AES-GCM + HMAC, see `crypto/crypto.ts`)
- Audit logging and session storage via better-sqlite3

## ML Pipeline
- See `ML_PIPELINE.md` for data schema, training, ONNX export, and integration
- Export training data for Ollama or other LLMs via the UI

## UI Walkthrough
- Timeline: color-coded chat history
- Detail pane: per-message flag, reason, tip
- LLM Training UI: build and export custom datasets
- Semantic Search: vector search and RAG answer generation
- Cluster Visualization: 2D embedding/flag cluster view

## Testing & QA
- See `TESTING_QA.md` for test/data guidelines
- PRs welcome for new plugins, ML models, UI features

## License
MIT License (see `LICENSE`)

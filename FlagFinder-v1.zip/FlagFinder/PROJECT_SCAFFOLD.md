# FlagFinder Project Scaffold

```
FlagFinder/
├── ARCHITECTURE.md
├── TECH_STACK.md
├── README.md
├── types.ts
├── cli/
│   └── index.ts
├── dispatcher/
│   ├── Dispatcher.ts
│   └── PluginRegistry.ts
├── ml/
│   ├── schema.ts
│   ├── train.py
│   └── requirements.txt
├── plugins/
│   ├── api/
│   │   └── APIPlugin.ts
│   ├── audio/
│   │   └── AudioPlugin.ts
│   ├── image/
│   │   └── ImagePlugin.ts
│   └── text/
│       └── TextPlugin.ts
├── test/
│   └── TextPlugin.test.ts
├── ui/
│   └── index.html
├── api/
│   └── server.ts
├── package.json
├── tsconfig.json
├── .env.example
├── .gitignore
└── Dockerfile (optional)
```

- All core plugins in `/plugins/`
- ML pipeline in `/ml/`
- Dispatcher and registry in `/dispatcher/`
- CLI in `/cli/`
- API server in `/api/`
- UI in `/ui/`
- Tests in `/test/`
- Types/interfaces in `types.ts`

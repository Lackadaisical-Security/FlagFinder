import { Plugin } from '../types';
import { TextPlugin } from '../plugins/text/TextPlugin';
import { AudioPlugin } from '../plugins/audio/AudioPlugin';
import { ImagePlugin } from '../plugins/image/ImagePlugin';
import { APIPlugin } from '../plugins/api/APIPlugin';

export function loadPlugins(): Plugin[] {
  return [
    new TextPlugin(),
    new AudioPlugin(),
    new ImagePlugin(),
    new APIPlugin(),
  ];
}

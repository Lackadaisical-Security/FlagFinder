import { Plugin, InputPayload, AnalysisResult } from '../types';
import { loadPlugins } from './PluginRegistry';

export class Dispatcher {
  private plugins: Plugin[];

  constructor() {
    this.plugins = loadPlugins();
  }

  async analyze(input: InputPayload): Promise<AnalysisResult[]> {
    // ...rate limiting, anonymization...
    const results: AnalysisResult[] = [];
    for (const plugin of this.plugins) {
      if (plugin.canHandle(input)) {
        results.push(await plugin.run(input));
      }
    }
    return results;
  }
}

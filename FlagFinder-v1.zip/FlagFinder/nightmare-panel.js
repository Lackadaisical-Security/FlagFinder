// Nightmare.js panel controller for FlagFinder Electron app
const Nightmare = require('nightmare');
const path = require('path');

// Configure Nightmare to use our Electron app
const nightmare = Nightmare({
  show: true,                    // Show the browser window
  width: 1200,
  height: 800,
  webPreferences: {
    nodeIntegration: true,
    contextIsolation: false,
    enableRemoteModule: true
  },
  // Use Electron as the browser
  electronPath: require('electron'),
  // Point to our built app
  dock: true,
  openDevTools: {
    mode: 'detach'
  }
});

async function launchFlagFinderPanel() {
  try {
    console.log('🚀 Launching FlagFinder with Nightmare.js...');
      // Load the built UI
    const htmlPath = path.join(__dirname, 'ui', 'nightmare-index.html');
    console.log('📂 Loading UI from:', htmlPath);
      await nightmare
      .goto(`file://${htmlPath}`)
      .wait('body')  // Wait for body element to load
      .wait(2000)    // Additional wait for scripts to execute
      .evaluate(() => {
        // Inject some test data into the app
        console.log('FlagFinder UI loaded successfully!');
        console.log('Document ready state:', document.readyState);
        console.log('Document body:', document.body ? 'exists' : 'missing');
        console.log('Document title:', document.title);
        
        // Check if our HTML app loaded
        const container = document.querySelector('.container');
        const textArea = document.getElementById('conversation');
        
        if (container && textArea) {
          console.log('✅ HTML app loaded correctly');
          // Auto-click the analyze button to test functionality
          const analyzeBtn = document.querySelector('button[onclick="analyzeConversation()"]');
          if (analyzeBtn) {
            console.log('🔄 Auto-triggering analysis demo...');
            setTimeout(() => analyzeBtn.click(), 1000);
          }
          return 'HTML app loaded successfully';
        } else {
          console.log('❌ HTML elements not found');
          console.log('Available elements:', document.body.innerHTML.substring(0, 200));
          return 'App elements missing';
        }
      })      .then((result) => {
        console.log('📊 UI Status:', result);
        
        // Take a screenshot
        return nightmare.screenshot(path.join(__dirname, 'flagfinder-screenshot.png'));
      })
      .then(() => {
        console.log('📸 Screenshot saved as flagfinder-screenshot.png');
        
        // Test the analysis functionality
        return nightmare
          .wait(3000)  // Wait for auto-analysis to complete
          .evaluate(() => {
            const resultsDiv = document.getElementById('results');
            if (resultsDiv && resultsDiv.style.display !== 'none') {
              console.log('✅ Analysis results are visible');
              const messages = document.querySelectorAll('.message');
              console.log(`📊 Found ${messages.length} analyzed messages`);
              return `Analysis working: ${messages.length} messages processed`;
            } else {
              console.log('❌ Analysis results not visible');
              return 'Analysis not working';
            }
          });
      })
      .then((analysisResult) => {
        console.log('🧠 Analysis Test:', analysisResult);
        
        // Keep the window open for interaction
        console.log('\n✅ FlagFinder panel is ready!');
        console.log('💡 The Electron window should be visible now');
        console.log('🔧 You can interact with the app manually');
        console.log('🔍 Try analyzing different conversations');
        console.log('⏹️  Press Ctrl+C to close the panel');
        
        // Keep the process alive
        return new Promise(() => {});
      });
      
  } catch (error) {
    console.error('❌ Error launching FlagFinder panel:', error);
    await nightmare.end();
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n🛑 Shutting down FlagFinder panel...');
  await nightmare.end();
  process.exit(0);
});

// Launch the panel
launchFlagFinderPanel();

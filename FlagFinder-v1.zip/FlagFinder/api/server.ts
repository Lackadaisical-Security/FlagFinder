import { Dispatcher } from '../dispatcher/Dispatcher';
import express from 'express';
import bodyParser from 'body-parser';

const app = express();
const dispatcher = new Dispatcher();

app.use(bodyParser.json());

app.post('/analyze', async (req: any, res: any) => {
  const { type, data, meta } = req.body;
  if (!type || !data) {
    return res.status(400).json({ error: 'Missing type or data' });
  }
  try {
    const results = await dispatcher.analyze({ type, data, meta });
    res.json(results);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`FlagFinder API listening on port ${port}`);
});

# FlagFinder API Reference

## Overview

FlagFinder exposes its core analysis, ML, and storage features via Electron preload and a REST API. This document describes the available endpoints and methods for integration and extension.

---

## Electron Preload API (window.flagfinder)

### Analysis & ML
- `analyzeLogs(transcript)` — Analyze chat logs (rule-based)
- `analyzeLogsWithML(transcript, useML)` — Analyze with ML classifier
- `loadModel(modelPath)` — Load ONNX model
- `getModelInfo()` — Get model input/output metadata
- `classify(text, features)` — Classify a single message
- `classifyBatch(texts, featuresArr)` — Batch classification
- `classifyMultiLabel(text, features)` — Multi-label classification
- `getEmbedding(text)` — Get embedding vector
- `addToEmbeddingStore(text)` — Add text to in-memory vector store
- `clearEmbeddingStore()` — Clear vector store
- `semanticSearch(query, topK)` — Semantic search (vector retrieval)
- `llmRAG(query, context)` — Retrieval-augmented generation (RAG) with LLM/Ollama

### Storage & Security
- `saveVault(data, passphrase)` — Save encrypted session
- `loadVault(passphrase)` — Load encrypted session
- `saveSession(data, encrypted)` — Save session to SQLite
- `loadSession(id)` — Load session from SQLite
- `listSessions()` — List all sessions
- `logAudit(event, details)` — Write to audit log
- `listAuditLogs(limit)` — List audit log entries

### Model Management
- `isModelLoaded()` — Check if ONNX model is loaded
- `unloadModel()` — Unload model
- `listAvailableModels(dir)` — List ONNX models in directory
- `exportOllamaTrainingData(data, outDir)` — Export training data for Ollama

---

## REST API (Optional)

See `/api/server.ts` for REST/GraphQL endpoints. Example:

- `POST /analyze` — Analyze input `{ type, data, meta }`

---

## Extending FlagFinder
- Add new plugins by implementing the `Plugin` interface and registering in `dispatcher/PluginRegistry.ts`
- Extend the UI by adding new React components in `/ui/`
- Add new ML models by exporting ONNX and placing in `/models/`

---

## See Also
- `DOCUMENTATION.md` — Full setup, plugin authoring, and UI walkthrough
- `ML_PIPELINE.md` — ML training, ONNX export, and integration
- `TESTING_QA.md` — Testing and QA

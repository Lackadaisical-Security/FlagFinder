import Database from 'better-sqlite3';
import path from 'path';

const dbPath = path.join(process.cwd(), 'flagfinder.db');
const db = new Database(dbPath);

db.exec(`
CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp TEXT,
  event TEXT,
  details TEXT
);
CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT,
  data TEXT,
  encrypted INTEGER
);
`);

export function logAudit(event: string, details: any) {
  db.prepare('INSERT INTO audit_log (timestamp, event, details) VALUES (?, ?, ?)')
    .run(new Date().toISOString(), event, JSON.stringify(details));
}

export function saveSession(data: any, encrypted = 0) {
  db.prepare('INSERT INTO sessions (created_at, data, encrypted) VALUES (?, ?, ?)')
    .run(new Date().toISOString(), JSON.stringify(data), encrypted);
  logAudit('saveSession', { encrypted });
}

export function loadSession(id: number) {
  const row = db.prepare('SELECT * FROM sessions WHERE id = ?').get(id);
  logAudit('loadSession', { id });
  return row;
}

export function listSessions() {
  return db.prepare('SELECT id, created_at, encrypted FROM sessions ORDER BY id DESC').all();
}

export function listAuditLogs(limit = 100) {
  return db.prepare('SELECT * FROM audit_log ORDER BY id DESC LIMIT ?').all(limit);
}

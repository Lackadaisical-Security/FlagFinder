import fs from 'fs';
const VAULT_PATH = 'flagfinder.vault';

export function saveVault(encrypted: string): boolean {
  fs.writeFileSync(VAULT_PATH, encrypted, 'utf-8');
  return true;
}

export function loadVault(): string {
  return fs.readFileSync(VAULT_PATH, 'utf-8');
}

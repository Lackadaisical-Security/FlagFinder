import React from 'react';

export default function DetailPane({ message }) {
  if (!message) return <div>Select a message to see details.</div>;
  return (
    <div style={{ border: '1px solid #ccc', padding: 16, marginTop: 16 }}>
      <h3>Message Details</h3>
      <p><b>Text:</b> {message.text}</p>
      <p><b>Flag:</b> {message.flag}</p>
      <p><b>Reason:</b> {message.reason}</p>
      <p><b>Tip:</b> {message.tip}</p>
    </div>
  );
}

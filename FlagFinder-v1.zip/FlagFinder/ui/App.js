import React, { useState, useEffect } from 'react';
import Timeline from './Timeline';
import DetailPane from './DetailPane';
import LLMTrainingUI from './LLMTrainingUI';
import SemanticSearchUI from './SemanticSearchUI';
import ClusterViz from './ClusterViz';

export default function App() {
  const [messages, setMessages] = useState([]);
  const [selected, setSelected] = useState(null);
  const [input, setInput] = useState('');
  const [useML, setUseML] = useState(false);
  const [modelList, setModelList] = useState([]);
  const [modelPath, setModelPath] = useState('');
  const [modelInfo, setModelInfo] = useState(null);
  const [vaultPass, setVaultPass] = useState('');
  const [sessions, setSessions] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [searchResults, setSearchResults] = useState([]);
  const [embeddings, setEmbeddings] = useState([]);
  const [labels, setLabels] = useState([]);

  // On mount, list available ONNX models
  useEffect(() => {
    if (window.flagfinder && window.flagfinder.listAvailableModels) {
      window.flagfinder.listAvailableModels('models').then(setModelList);
    }
  }, []);

  // Load model and get info
  const handleLoadModel = async (path) => {
    if (window.flagfinder && window.flagfinder.loadModel) {
      await window.flagfinder.loadModel(path);
      setModelPath(path);
      if (window.flagfinder.getModelInfo) {
        setModelInfo(await window.flagfinder.getModelInfo());
      }
    }
  };

  const handleAnalyze = async () => {
    if (!input) return;
    let result;
    if (window.flagfinder) {
      if (useML && modelPath) {
        result = await window.flagfinder.analyzeLogsWithML(input, true);
      } else {
        result = await window.flagfinder.analyzeLogs(input);
      }
    } else {
      result = { messages: [] };
    }
    setMessages(result.messages || []);
    setSelected(null);
  };

  // Save encrypted session
  const handleSaveVault = async () => {
    if (window.flagfinder && vaultPass) {
      await window.flagfinder.saveVault(messages, vaultPass);
      alert('Session saved (encrypted)');
    }
  };

  // Load encrypted session
  const handleLoadVault = async () => {
    if (window.flagfinder && vaultPass) {
      const loaded = await window.flagfinder.loadVault(vaultPass);
      setMessages(loaded);
      setSelected(null);
    }
  };

  useEffect(() => {
    if (window.flagfinder && window.flagfinder.listSessions) {
      window.flagfinder.listSessions().then(setSessions);
    }
    if (window.flagfinder && window.flagfinder.listAuditLogs) {
      window.flagfinder.listAuditLogs(50).then(setAuditLogs);
    }
  }, [messages]);

  const handleLoadSession = async (id) => {
    if (window.flagfinder && window.flagfinder.loadSession) {
      const row = await window.flagfinder.loadSession(id);
      setMessages(JSON.parse(row.data));
      setSelected(null);
    }
  };

  // Add all messages to embedding store for semantic search
  const handleAddAllToEmbeddingStore = async () => {
    if (window.flagfinder && messages.length > 0) {
      await window.flagfinder.clearEmbeddingStore();
      for (const msg of messages) {
        await window.flagfinder.addToEmbeddingStore(msg.text);
      }
      alert('All messages added to embedding store for semantic search.');
    }
  };

  // Semantic search handler
  const handleSemanticSearch = async (query) => {
    if (window.flagfinder) {
      const results = await window.flagfinder.semanticSearch(query, 5);
      setSearchResults(results);
    }
  };

  // RAG handler (simulate with local LLM or placeholder)
  const handleRAG = async (query, context) => {
    if (window.flagfinder && window.flagfinder.llmRAG) {
      return await window.flagfinder.llmRAG(query, context);
    }
    // Fallback: simple concatenation
    return `Q: ${query}\nContext:\n${context}\nA: [LLM output here]`;
  };

  // Compute embeddings for all messages for cluster viz
  const handleComputeEmbeddings = async () => {
    if (window.flagfinder && messages.length > 0) {
      const embs = [];
      const lbls = [];
      for (const msg of messages) {
        const emb = await window.flagfinder.getEmbedding(msg.text);
        embs.push(emb.slice(0, 2)); // Use first 2 dims for 2D viz
        // Map flag to label index
        lbls.push(msg.flag === '🟢' ? 0 : msg.flag === '🟡' ? 1 : 2);
      }
      setEmbeddings(embs);
      setLabels(lbls);
    }
  };

  return (
    <div style={{ maxWidth: 800, margin: 'auto', padding: 24 }}>
      <h1>FlagFinder</h1>
      <textarea
        rows={8}
        style={{ width: '100%' }}
        value={input}
        onChange={e => setInput(e.target.value)}
        placeholder="Paste chat transcript here..."
      />
      <div style={{ margin: '12px 0' }}>
        <label>
          <input type="checkbox" checked={useML} onChange={e => setUseML(e.target.checked)} /> Use ML Classifier
        </label>
        {useML && (
          <span style={{ marginLeft: 16 }}>
            Model:
            <select value={modelPath} onChange={e => handleLoadModel(e.target.value)}>
              <option value="">Select model</option>
              {modelList.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
            {modelInfo && <span style={{ marginLeft: 8 }}>Inputs: {modelInfo.inputNames.join(', ')}</span>}
          </span>
        )}
      </div>
      <button onClick={handleAnalyze} style={{ margin: '12px 0' }}>Analyze</button>
      <Timeline messageList={messages} onSelect={setSelected} />
      <DetailPane message={selected} />
      <LLMTrainingUI />
      <button onClick={handleAddAllToEmbeddingStore} style={{ marginTop: 16 }}>Add All Messages to Embedding Store</button>
      <SemanticSearchUI onSearch={handleSemanticSearch} results={searchResults} onRAG={handleRAG} />
      <button onClick={handleComputeEmbeddings} style={{ marginTop: 16 }}>Visualize Clusters</button>
      <ClusterViz embeddings={embeddings} labels={labels} />
      <div style={{ marginTop: 24 }}>
        <h3>Encrypted Session</h3>
        <input type="password" placeholder="Vault passphrase" value={vaultPass} onChange={e => setVaultPass(e.target.value)} />
        <button onClick={handleSaveVault}>Save</button>
        <button onClick={handleLoadVault}>Load</button>
      </div>
      <div style={{ marginTop: 24 }}>
        <h3>Saved Sessions</h3>
        <ul>
          {sessions.map(s => (
            <li key={s.id}>
              <button onClick={() => handleLoadSession(s.id)}>Load</button>
              &nbsp;Session #{s.id} ({s.created_at}) {s.encrypted ? '[Encrypted]' : ''}
            </li>
          ))}
        </ul>
      </div>
      <div style={{ marginTop: 24 }}>
        <h3>Audit Log</h3>
        <ul style={{ maxHeight: 200, overflowY: 'auto' }}>
          {auditLogs.map(l => (
            <li key={l.id}>
              [{l.timestamp}] <b>{l.event}</b>: {l.details}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

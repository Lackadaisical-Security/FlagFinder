import React, { useState } from 'react';

export default function Timeline({ messageList, onSelect }) {
  return (
    <div>
      <h2>Timeline</h2>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {messageList.map((msg, i) => (
          <li key={i} style={{ margin: '8px 0', cursor: 'pointer' }} onClick={() => onSelect(msg)}>
            <span style={{ fontSize: '1.5em' }}>{msg.flag}</span> {msg.text}
          </li>
        ))}
      </ul>
    </div>
  );
}

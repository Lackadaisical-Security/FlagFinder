import React, { useRef, useEffect } from 'react';

export default function ClusterViz({ embeddings, labels }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!embeddings || embeddings.length === 0) return;
    // Simple 2D projection (PCA or t-SNE would be better, but use first 2 dims for demo)
    const ctx = canvasRef.current.getContext('2d');
    ctx.clearRect(0, 0, 400, 400);
    const colors = ['#4caf50', '#ffeb3b', '#f44336'];
    embeddings.forEach((emb, i) => {
      const x = 200 + (emb[0] * 80);
      const y = 200 + (emb[1] * 80);
      ctx.beginPath();
      ctx.arc(x, y, 8, 0, 2 * Math.PI);
      ctx.fillStyle = colors[labels[i] || 0];
      ctx.fill();
      ctx.stroke();
    });
  }, [embeddings, labels]);

  return (
    <div style={{ marginTop: 24 }}>
      <h3>Cluster Visualization</h3>
      <canvas ref={canvasRef} width={400} height={400} style={{ border: '1px solid #ccc' }} />
      <div style={{ fontSize: 12, marginTop: 8 }}>
        <span style={{ color: '#4caf50' }}>🟢 Green</span> &nbsp;
        <span style={{ color: '#ffeb3b' }}>🟡 Caution</span> &nbsp;
        <span style={{ color: '#f44336' }}>🔴 Red</span>
      </div>
    </div>
  );
}

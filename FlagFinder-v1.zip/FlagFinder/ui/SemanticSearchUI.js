import React, { useState } from 'react';

export default function SemanticSearchUI({ onSearch, results, onRAG }) {
  const [query, setQuery] = useState('');
  const [ragResult, setRagResult] = useState('');

  const handleSearch = async () => {
    if (onSearch) await onSearch(query);
  };

  const handleRAG = async () => {
    if (onRAG && query) {
      const context = results.map(r => r.text).join('\n');
      const completion = await onRAG(query, context);
      setRagResult(completion);
    }
  };

  return (
    <div style={{ border: '1px solid #ccc', padding: 16, marginTop: 24 }}>
      <h2>Semantic Search (LLM/Vector)</h2>
      <input
        type="text"
        value={query}
        onChange={e => setQuery(e.target.value)}
        placeholder="Enter search query..."
        style={{ width: '70%' }}
      />
      <button onClick={handleSearch} style={{ marginLeft: 8 }}>Search</button>
      <button onClick={handleRAG} style={{ marginLeft: 8 }}>RAG (Generate Answer)</button>
      <ul>
        {results.map((r, i) => (
          <li key={i}>
            <b>Score:</b> {r.score.toFixed(3)}<br />
            <span>{r.text}</span>
          </li>
        ))}
      </ul>
      {ragResult && (
        <div style={{ marginTop: 16, background: '#f9f9f9', padding: 12, borderRadius: 4 }}>
          <b>RAG Output:</b>
          <pre style={{ whiteSpace: 'pre-wrap' }}>{ragResult}</pre>
        </div>
      )}
    </div>
  );
}

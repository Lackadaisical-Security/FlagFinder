import React, { useState } from 'react';

export default function LLMTrainingUI() {
  const [examples, setExamples] = useState([]);
  const [text, setText] = useState('');
  const [label, setLabel] = useState('green');
  const [exportPath, setExportPath] = useState('');

  const addExample = () => {
    setExamples([...examples, { text, features: {}, label }]);
    setText('');
    setLabel('green');
  };

  const handleExport = async () => {
    if (window.flagfinder && window.flagfinder.exportOllamaTrainingData) {
      const path = await window.flagfinder.exportOllamaTrainingData(examples);
      setExportPath(path);
    }
  };

  return (
    <div style={{ border: '1px solid #ccc', padding: 16, marginTop: 24 }}>
      <h2>Custom LLM Training Data Builder</h2>
      <textarea
        rows={3}
        style={{ width: '100%' }}
        value={text}
        onChange={e => setText(e.target.value)}
        placeholder="Enter example message..."
      />
      <select value={label} onChange={e => setLabel(e.target.value)}>
        <option value="green">🟢 Green</option>
        <option value="caution">🟡 Caution</option>
        <option value="red">🔴 Red</option>
      </select>
      <button onClick={addExample} style={{ marginLeft: 8 }}>Add Example</button>
      <ul>
        {examples.map((ex, i) => (
          <li key={i}>{ex.text} <b>{ex.label}</b></li>
        ))}
      </ul>
      <button onClick={handleExport} disabled={examples.length === 0}>Export for Ollama</button>
      {exportPath && <div>Exported to: {exportPath}</div>}
    </div>
  );
}

# FlagFinder ML Pipeline

## Data Schema
- See `ml/schema.ts` for the `LabeledExample` interface:
  - `text: string` — message text
  - `features: Record<string, number>` — rule-based features (e.g., sentiment, question rate)
  - `label: 'green' | 'caution' | 'red'` — ground truth flag

## Training Script
- `ml/train.py` (Python):
  - Loads labeled examples (JSON/CSV)
  - Extracts features
  - Fine-tunes transformer (e.g., RoBERTa, GPT-2)
  - Merges rule-based features with contextual embeddings
  - Exports model for inference (ONNX or PyTorch)

## Inference
- Node.js calls Python for inference, or loads ONNX model locally
- Rule-based and ML scores are merged in post-processing

## Evaluation
- Metrics: accuracy, F1, confusion matrix (per flag)
- Test on synthetic and real chat data

## Integration
- Plugins (Text, Audio, Image, API) all funnel text to the ML pipeline after pre-processing
- Unified output: per-message flag, score, tip, and chat summary

import { Plugin, InputPayload, AnalysisResult } from '../../types';
import { TextPlugin } from '../text/TextPlugin';

export class ImagePlugin implements Plugin {
  name = 'ImagePlugin';
  
  canHandle(input: InputPayload): boolean {
    return input.type === 'image';
  }
  
  async run(input: InputPayload): Promise<AnalysisResult> {
    // TODO: Integrate real OCR (Tesseract.js) here
    const extractedText = '[OCR extracted text placeholder]';
    // Optionally, pass meta info (e.g., timestamp) if available
    return new TextPlugin().run({ type: 'text', data: extractedText, meta: input.meta });
  }
}

import { Plugin, InputPayload, AnalysisResult } from '../../types';

// Simple PII removal (stub)
function removePII(text: string): string {
  // Remove emails, phone numbers (very basic)
  return text.replace(/\b[\w.-]+@[\w.-]+\b/g, '[email]')
             .replace(/\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/g, '[phone]');
}

// Normalize text (lowercase, trim)
function normalize(text: string): string {
  return text.toLowerCase().trim();
}

// Rule-based scanner (keywords, sentiment, etc.)
function ruleScan(text: string): { flag: '🟢' | '🟡' | '🔴'; score: number; tip: string } {
  const softNos = ["busy", "maybe later", "not sure", "...", "idk", "can't", "not today"];
  const redFlags = ["leave me alone", "stop", "never", "hate you"];
  const yellowFlags = ["hmm", "maybe", "not now", "later"];
  const t = text.toLowerCase();
  if (redFlags.some(k => t.includes(k))) return { flag: '🔴', score: 0.95, tip: 'Strong negative detected' };
  if (softNos.some(k => t.includes(k)) || yellowFlags.some(k => t.includes(k))) return { flag: '🟡', score: 0.6, tip: 'Possible soft no or hesitation' };
  return { flag: '🟢', score: 0.1, tip: 'No issues detected' };
}

// ML classifier stub (to be replaced with real model call)
async function mlClassify(text: string, features: Record<string, number>): Promise<{ flag: '🟢' | '🟡' | '🔴'; score: number }> {
  // TODO: Call Python ML service or ONNX model
  // For now, echo rule-based result
  const rule = ruleScan(text);
  return { flag: rule.flag, score: rule.score };
}

export class TextPlugin implements Plugin {
  name = 'TextPlugin';
  canHandle(input: InputPayload): boolean {
    return input.type === 'text';
  }
  async run(input: InputPayload): Promise<AnalysisResult> {
    // Pre-process
    let text = input.data;
    text = normalize(removePII(text));
    // Rule-based scan
    const rule = ruleScan(text);
    // ML classifier (stub)
    const ml = await mlClassify(text, {});
    // Post-process: merge rule and ML (simple average for now)
    const avgScore = (rule.score + ml.score) / 2;
    const finalFlag = avgScore > 0.8 ? '🔴' : avgScore > 0.4 ? '🟡' : '🟢';
    return {
      text,
      flag: finalFlag,
      score: avgScore,
      tip: rule.tip + (ml.flag !== rule.flag ? ' (ML disagrees)' : '')
    };
  }
}

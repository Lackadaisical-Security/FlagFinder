import { Plugin, InputPayload, AnalysisResult } from '../../types';
import { TextPlugin } from '../text/TextPlugin';

export class APIPlugin implements Plugin {
  name = 'APIPlugin';
  
  canHandle(input: InputPayload): boolean {
    return input.type === 'api';
  }
  
  async run(input: InputPayload): Promise<AnalysisResult> {
    // TODO: Process API feed (webhook payload, etc.)
    // For now, treat as text
    return new TextPlugin().run({ type: 'text', data: input.data, meta: input.meta });
  }
}

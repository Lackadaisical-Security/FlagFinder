export interface LabeledExample {
  text: string;
  features: Record<string, number>;
  label: 'green' | 'caution' | 'red';
}

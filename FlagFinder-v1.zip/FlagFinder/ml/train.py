# Train a transformer classifier with rule-based features
# TODO: Integrate Hugging Face Transformers and fuse rule-based features into the classifier pipeline

import json
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
from sklearn.model_selection import train_test_split
from datasets import Dataset
import numpy as np

# Load data (expects a JSONL file with {"text":..., "features":..., "label":...})
def load_data(path):
    import jsonlines
    data = []
    with jsonlines.open(path) as reader:
        for obj in reader:
            data.append(obj)
    return data

def compute_metrics(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=1)
    acc = (preds == labels).mean()
    return {"accuracy": acc}

# Main training function
def train_model(data_path, model_name="distilbert-base-uncased", output_dir="./model_out"):
    data = load_data(data_path)
    texts = [d["text"] for d in data]
    labels = [0 if d["label"]=="green" else 1 if d["label"]=="caution" else 2 for d in data]
    features = [list(d["features"].values()) for d in data]
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    # Tokenize text
    encodings = tokenizer(texts, truncation=True, padding=True)
    # Add features as additional input (if model supports)
    # For now, just use text
    ds = Dataset.from_dict({"input_ids": encodings["input_ids"], "attention_mask": encodings["attention_mask"], "label": labels})
    train_ds, val_ds = ds.train_test_split(test_size=0.2).values()
    model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=3)
    args = TrainingArguments(output_dir=output_dir, evaluation_strategy="epoch", num_train_epochs=3)
    trainer = Trainer(model, args, train_dataset=train_ds, eval_dataset=val_ds, compute_metrics=compute_metrics)
    trainer.train()
    model.save_pretrained(output_dir)
    tokenizer.save_pretrained(output_dir)

# ONNX export utility
try:
    from transformers import AutoTokenizer, AutoModelForSequenceClassification
    import torch
except ImportError:
    AutoTokenizer = None
    AutoModelForSequenceClassification = None
    torch = None

def export_onnx(model_dir, onnx_path):
    if not AutoTokenizer or not AutoModelForSequenceClassification or not torch:
        print("ONNX export requires transformers and torch. Please install them.")
        return
    tokenizer = AutoTokenizer.from_pretrained(model_dir)
    model = AutoModelForSequenceClassification.from_pretrained(model_dir)
    dummy_input = tokenizer("This is a test", return_tensors="pt")
    torch.onnx.export(
        model,
        (dummy_input["input_ids"], dummy_input["attention_mask"]),
        onnx_path,
        input_names=["input_ids", "attention_mask"],
        output_names=["logits"],
        dynamic_axes={"input_ids": {0: "batch_size"}, "attention_mask": {0: "batch_size"}, "logits": {0: "batch_size"}},
        opset_version=13
    )
    print(f"Exported ONNX model to {onnx_path}")

if __name__ == "__main__":
    import sys
    train_model(sys.argv[1])
    if len(sys.argv) == 3:
        export_onnx(sys.argv[1], sys.argv[2])
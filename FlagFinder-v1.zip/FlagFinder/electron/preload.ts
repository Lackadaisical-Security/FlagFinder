import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('flagfinder', {
  analyzeLogs: (transcript: any) => ipcRenderer.invoke('analyzeLogs', transcript),
  analyzeLogsWithML: (transcript: any, useML: boolean) => ipcRenderer.invoke('analyzeLogsWithML', transcript, useML),
  loadModel: (modelPath: string) => ipcRenderer.invoke('loadModel', modelPath),
  getModelInfo: () => ipcRenderer.invoke('getModelInfo'),
  listAvailableModels: (dir: string) => ipcRenderer.invoke('listAvailableModels', dir),
  saveVault: (data: any, passphrase: string) => ipcRenderer.invoke('saveVault', data, passphrase),
  loadVault: (passphrase: string) => ipcRenderer.invoke('loadVault', passphrase),
  saveSession: (data: any, encrypted = 0) => ipcRenderer.invoke('saveSession', data, encrypted),
  loadSession: (id: number) => ipcRenderer.invoke('loadSession', id),
  listSessions: () => ipcRenderer.invoke('listSessions'),
  listAuditLogs: (limit: number) => ipcRenderer.invoke('listAuditLogs', limit),
  logAudit: (event: string, details: any) => ipcRenderer.invoke('logAudit', event, details),
  addToEmbeddingStore: (text: string) => ipcRenderer.invoke('addToEmbeddingStore', text),
  clearEmbeddingStore: () => ipcRenderer.invoke('clearEmbeddingStore'),
  semanticSearch: (query: string, topK: number) => ipcRenderer.invoke('semanticSearch', query, topK),
  llmRAG: (query: string, context: string) => ipcRenderer.invoke('llmRAG', query, context),
  getEmbedding: (text: string) => ipcRenderer.invoke('getEmbedding', text),
  exportOllamaTrainingData: (data: any, outDir?: string) => ipcRenderer.invoke('exportOllamaTrainingData', data, outDir),
});

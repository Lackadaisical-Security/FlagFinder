import { app, BrowserWindow, ipcMain } from 'electron';
import path from 'path';

function createWindow() {
  const win = new BrowserWindow({
    width: 1000,
    height: 700,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  
  // Load from webpack dev server in dev, or dist in production
  const isDev = process.env.NODE_ENV === 'development';
  if (isDev) {
    win.loadURL('http://localhost:3001');
    win.webContents.openDevTools();
  } else {
    win.loadFile(path.join(__dirname, 'index.html'));
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Import modules after app is ready
let analysisModule: any;
let mlModule: any;
let cryptoModule: any;
let storageModule: any;

app.whenReady().then(() => {
  analysisModule = require('../analysis/ruleEngine');
  mlModule = require('../analysis/mlPlugin');
  cryptoModule = require('../crypto/crypto');
  storageModule = require('../storage/sqlite');
});

// IPC Handlers
ipcMain.handle('analyzeLogs', async (_event, transcript) => {
  return analysisModule.analyzeLogs(transcript);
});

ipcMain.handle('analyzeLogsWithML', async (_event, transcript, useML) => {
  return analysisModule.analyzeLogsWithML(transcript, useML);
});

ipcMain.handle('loadModel', async (_event, modelPath) => {
  return mlModule.loadModel(modelPath);
});

ipcMain.handle('getModelInfo', async (_event) => {
  return mlModule.getModelInfo();
});

ipcMain.handle('listAvailableModels', async (_event, dir) => {
  return mlModule.listAvailableModels(dir);
});

ipcMain.handle('saveVault', async (_event, data, passphrase) => {
  return cryptoModule.saveVaultLackadaisical(data, passphrase);
});

ipcMain.handle('loadVault', async (_event, passphrase) => {
  return cryptoModule.loadVaultLackadaisical(passphrase);
});

ipcMain.handle('saveSession', async (_event, data, encrypted) => {
  return storageModule.saveSession(data, encrypted);
});

ipcMain.handle('loadSession', async (_event, id) => {
  return storageModule.loadSession(id);
});

ipcMain.handle('listSessions', async (_event) => {
  return storageModule.listSessions();
});

ipcMain.handle('listAuditLogs', async (_event, limit) => {
  return storageModule.listAuditLogs(limit);
});

ipcMain.handle('logAudit', async (_event, event, details) => {
  return storageModule.logAudit(event, details);
});

ipcMain.handle('addToEmbeddingStore', async (_event, text) => {
  return mlModule.addToEmbeddingStore(text);
});

ipcMain.handle('clearEmbeddingStore', async (_event) => {
  return mlModule.clearEmbeddingStore();
});

ipcMain.handle('semanticSearch', async (_event, query, topK) => {
  return mlModule.semanticSearch(query, topK);
});

ipcMain.handle('llmRAG', async (_event, query, context) => {
  return mlModule.llmRAG(query, context);
});

ipcMain.handle('getEmbedding', async (_event, text) => {
  return mlModule.getEmbedding(text);
});

ipcMain.handle('exportOllamaTrainingData', async (_event, data, outDir) => {
  return mlModule.exportOllamaTrainingData(data, outDir);
});

# FlagFinder Architecture Overview

## Component Diagram

```
+-------------------+      +-------------------+      +-------------------+
|                   |      |                   |      |                   |
|   Input Sources   +----->+    Dispatcher     +----->+     Plugins       |
| (Text/Audio/Img)  |      |                   |      | (Text/Audio/Img)  |
+-------------------+      +-------------------+      +-------------------+
        |                        |                            |
        v                        v                            v
+-------------------+      +-------------------+      +-------------------+
| Preprocessing     |----->| Rule-based        |----->| ML Classifier     |
| (Norm/OCR/STT)    |      | Scanner           |      | (Transformer)     |
+-------------------+      +-------------------+      +-------------------+
        |                        |                            |
        v                        v                            v
+-------------------+      +-------------------+      +-------------------+
| Post-processing   |----->| Output Formatter  |----->| Storage/Export    |
+-------------------+      +-------------------+      +-------------------+
```

## Data Flow (Example: Audio)

1. User uploads audio file
2. AudioPlugin transcribes audio (Whisper)
3. Text is normalized, PII removed
4. Rule-based scanner extracts features
5. ML classifier predicts flag
6. Post-processing merges results
7. Output: JSON/HTML report

## Key Modules
- Dispatcher: routes input to plugins, enforces privacy/rate limits
- Plugin Registry: dynamic plugin loading
- ML Service: rules + transformer classifier
- Storage: encrypted logs, reports
- UI/API/CLI: user interaction

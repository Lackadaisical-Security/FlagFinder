# FlagFinder Updated Architecture (Electron Desktop)

## Component Diagram

```
[UI Layer (React/HTML)]
   ↕ (IPC)
[Electron Main & Preload]
   ↕
[Analysis Engine (JS rules, sentiment, ML plugin)]
   ↕
[Crypto Module (AES-GCM)]
   ↕
[Encrypted Storage]
```

- **UI Layer**: React components (or HTML/JS) for import, timeline, detail pane
- **Electron Main**: Handles window, IPC endpoints (`analyzeLogs`, `loadModel`, `saveVault`)
- **Preload**: Exposes secure APIs to renderer
- **Analysis Engine**: Rule-based, sentiment, and (optionally) ML classifier
- **Crypto Module**: Encrypt/decrypt logs using user passphrase
- **Storage**: Encrypted session files on disk

## Data Flow
1. User imports transcript (text/JSON)
2. UI sends data to Electron main via IPC
3. Main process runs analysis (rules, sentiment, flags)
4. Results sent back to UI for timeline/detail display
5. User can save/load sessions (encrypted)
